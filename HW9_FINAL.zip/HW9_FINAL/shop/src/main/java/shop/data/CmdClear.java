package shop.data;
import shop.command.*;
import java.util.Map;

/**
 * Implementation of command to clear the inventory.
 * @see Data
 */
final class CmdClear implements UndoableCommand {
  public InventorySet _inventory;
  public Map<Video, Record> _oldvalue;
  CmdClear(InventorySet inventory) {
    _inventory = inventory;
  }
  public boolean run() {
    if (_oldvalue != null)
      return false;
    try {
      _oldvalue = _inventory.clear();
      _inventory.getHistory().add(this);
      return true;
    } catch (ClassCastException e) {
      return false;
    }
  }
  public void undo() {
    _inventory.replaceMap(_oldvalue);
  }
  public void redo() {
    _inventory.clear();
  }
}
