package shop.main;

import java.util.Scanner;
import java.util.Iterator;
import shop.command.*;
import shop.data.*;
import shop.data.Record;

public class Main {
    private static final Inventory inventory = Data.newInventory();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("\nWelcome to Trisha's Video Shop!");

        while (true) {
            displayMenu();
            int choice = getUserChoice();

            switch (choice) {
                case 1 -> addOrRemoveCopies();
                case 2 -> checkInOrOutVideo(true);
                case 3 -> checkInOrOutVideo(false);
                case 4 -> printInventory();
                case 5 -> clearInventory();
                case 6 -> undoRedo(true);
                case 7 -> undoRedo(false);
                case 8 -> printTopTenRentals();
                case 9 -> exit();
                case 10 -> initializeBogusContents();
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nEnter choice by number:");
        System.out.println("1. Add/Remove copies of a video");
        System.out.println("2. Check in a video");
        System.out.println("3. Check out a video");
        System.out.println("4. Print the inventory");
        System.out.println("5. Clear the inventory");
        System.out.println("6. Undo");
        System.out.println("7. Redo");
        System.out.println("8. Print top ten all-time rentals in order");
        System.out.println("9. Exit");
        System.out.println("10. Initialize with bogus contents");
    }

    private static int getUserChoice() {
        int choice;
        do {
            System.out.print("Choice: ");
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a valid number.");
                System.out.print("Choice: ");
                scanner.next(); // discard invalid input
            }
            choice = scanner.nextInt();
        } while (choice <= 0 || choice > 10);

        return choice;
    }

    private static void addOrRemoveCopies() {
        Video video = getVideoInfo();
        int change = getPositiveIntInput("Enter number of copies to add/remove: ");
        UndoableCommand cmd = Data.newAddCmd(inventory, video, change);
        executeCommand(cmd);
    }

    private static void checkInOrOutVideo(boolean checkIn) {
        Video video = getVideoInfo();
        UndoableCommand cmd = checkIn ? Data.newInCmd(inventory, video) : Data.newOutCmd(inventory, video);
        executeCommand(cmd);
    }

    private static void printInventory() {
        System.out.println(inventory);
    }

    private static void clearInventory() {
        UndoableCommand cmd = Data.newClearCmd(inventory);
        executeCommand(cmd);
    }

    private static void undoRedo(boolean isUndo) {
        RerunnableCommand cmd = isUndo ? Data.newUndoCmd(inventory) : Data.newRedoCmd(inventory);
        String operation = isUndo ? "Undo" : "Redo";
        
        if (cmd.run()) {
            System.out.println(operation + " successful.");
        } else {
            System.out.println("Nothing to " + operation.toLowerCase() + ".");
        }
    }

    private static void printTopTenRentals() {
        Iterator<Record> iter = inventory.iterator((r1, r2) -> r2.numRentals() - r1.numRentals());

        System.out.println("Top ten all-time rentals:");
        int count = 0;
        while (iter.hasNext() && count < 10) {
            Record record = iter.next();
            System.out.println(record.video().title() + " - " + record.numRentals() + " rentals");
            count++;
        }
    }

    private static void initializeBogusContents() {
        Video[] videos = {
            Data.newVideo("The Shawshank Redemption", 1994, "Frank Darabont"),
            Data.newVideo("The Godfather", 1972, "Francis Ford Coppola"),
            Data.newVideo("The Dark Knight", 2008, "Christopher Nolan")
        };

        for (Video video : videos) {
            UndoableCommand cmd = Data.newAddCmd(inventory, video, 10);
            executeCommand(cmd);
        }

        System.out.println("Initialized with bogus contents.");
    }

    private static Video getVideoInfo() {
        System.out.print("Enter video title: ");
        String title = scanner.next();
        int year = getPositiveIntInput("Enter video year: ");
        System.out.print("Enter video director: ");
        String director = scanner.next();
        return Data.newVideo(title, year, director);
    }

    private static int getPositiveIntInput(String prompt) {
        int input;
        do {
            System.out.print(prompt);
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a valid number.");
                System.out.print(prompt);
                scanner.next(); // discard invalid input
            }
            input = scanner.nextInt();
        } while (input <= 0);

        return input;
    }

    private static void executeCommand(UndoableCommand cmd) {
        if (cmd.run()) {
            System.out.println("Command executed successfully.");
        } else {
            System.out.println("Failed to execute command.");
        }
    }

    private static void exit() {
        System.out.println("Exiting...");
        System.exit(0);
    }
}
