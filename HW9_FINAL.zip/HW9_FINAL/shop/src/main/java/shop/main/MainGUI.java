package shop.main;

import shop.command.*;
import shop.data.*;
import shop.data.Record;
import java.util.Iterator;
import javax.swing.JOptionPane;

public class MainGUI {
    private static final String MENU =
            "Welcome to Trisha's Video Shop!\n" +
            "Enter choice by number:\n" +
            "1. Add/Remove copies of a video\n" +
            "2. Check in a video\n" +
            "3. Check out a video\n" +
            "4. Print the inventory\n" +
            "5. Clear the inventory\n" +
            "6. Undo\n" +
            "7. Redo\n" +
            "8. Print top ten all-time rentals in order\n" +
            "9. Exit\n" +
            "10. Initialize with bogus contents";

    private static final Inventory inventory = Data.newInventory();

    public static void main(String[] args) {
        displayMenu();
    }

    private static void displayMenu() {
        int choice = getChoiceInput();
        handleChoice(choice);
    }

    private static int getChoiceInput() {
        String choiceString = JOptionPane.showInputDialog(null, MENU, "Main Menu", JOptionPane.PLAIN_MESSAGE);
        return parseChoice(choiceString);
    }

    private static int parseChoice(String choiceString) {
        try {
            return Integer.parseInt(choiceString);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static void handleChoice(int choice) {
        switch (choice) {
            case 1:
                addOrRemoveCopies(true);
                break;
            case 2:
                checkInOrOutVideo(true);
                break;
            case 3:
                checkInOrOutVideo(false);
                break;
            case 4:
                printInventory();
                break;
            case 5:
                clearInventory();
                break;
            case 6:
                undoRedo(true);
                break;
            case 7:
                undoRedo(false);
                break;
            case 8:
                printTopTenRentals();
                break;
            case 9:
                exit();
                break;
            case 10:
                initializeBogusContents();
                break;
            default:
                displayError("Invalid choice. Please try again.");
                displayMenu();
        }
    }

    private static void addOrRemoveCopies(boolean add) {
        Video video = getVideoFromUser();
        int change = getIntInput("Enter number of copies to " + (add ? "add" : "remove") + ":");
        UndoableCommand cmd = Data.newAddCmd(inventory, video, (add ? change : -change));
        executeCommand(cmd, "Command executed successfully.");
    }

    private static Video getVideoFromUser() {
        String title = JOptionPane.showInputDialog("Enter video title:");
        int year = getIntInput("Enter video year:");
        String director = JOptionPane.showInputDialog("Enter video director:");
        return Data.newVideo(title, year, director);
    }

    private static int getIntInput(String prompt) {
        while (true) {
            try {
                return Integer.parseInt(JOptionPane.showInputDialog(prompt));
            } catch (NumberFormatException e) {
                displayError("Invalid input. Please enter a valid integer.");
            }
        }
    }

    private static void checkInOrOutVideo(boolean checkIn) {
        Video video = getVideoFromUser();
        UndoableCommand cmd = (checkIn ? Data.newInCmd(inventory, video) : Data.newOutCmd(inventory, video));
        executeCommand(cmd, "Command executed successfully.");
    }

    private static void printInventory() {
        displayMessage(inventory.toString());
        displayMenu();
    }

    private static void clearInventory() {
        UndoableCommand cmd = Data.newClearCmd(inventory);
        executeCommand(cmd, "Command executed successfully.");
    }

    private static void undoRedo(boolean isUndo) {
        RerunnableCommand cmd = (isUndo ? Data.newUndoCmd(inventory) : Data.newRedoCmd(inventory));
        String operation = isUndo ? "Undo" : "Redo";
        executeCommand(cmd, operation + " successful.");
    }

    private static void printTopTenRentals() {
        Iterator<Record> iter = inventory.iterator((r1, r2) -> r2.numRentals() - r1.numRentals());
        StringBuilder topTenRentals = new StringBuilder("Top ten all-time rentals:\n");
        int count = 0;
        while (iter.hasNext() && count++ < 10) {
            Record record = iter.next();
            topTenRentals.append(record.video().title()).append(" - ").append(record.numRentals()).append(" rentals\n");
        }
        displayMessage(topTenRentals.toString());
        displayMenu();
    }

    private static void initializeBogusContents() {
        Video video1 = Data.newVideo("The Shawshank Redemption", 1994, "Frank Darabont");
        Video video2 = Data.newVideo("The Godfather", 1972, "Francis Ford Coppola");
        Video video3 = Data.newVideo("The Dark Knight", 2008, "Christopher Nolan");
        executeCommands(
                Data.newAddCmd(inventory, video1, 10),
                Data.newAddCmd(inventory, video2, 8),
                Data.newAddCmd(inventory, video3, 12));
        displayMessage("Initialized with bogus contents.");
        displayMenu();
    }

    private static void executeCommand(Command cmd, String successMessage) {
        if (cmd.run()) {
            displayMessage(successMessage);
            displayMenu();
        } else {
            displayError("Failed to execute command.");
            displayMenu();
        }
    }

    private static void executeCommands(Command... commands) {
        for (Command cmd : commands) {
            if (!cmd.run()) {
                displayError("Failed to execute command.");
                displayMenu();
                return;
            }
        }
    }

    private static void displayMessage(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

    private static void displayError(String message) {
        JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private static void exit() {
        displayMessage("Exiting...");
        System.exit(0);
    }
}
