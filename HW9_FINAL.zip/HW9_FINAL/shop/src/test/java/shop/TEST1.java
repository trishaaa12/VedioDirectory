package shop;

import shop.command.*;
import shop.data.Data;
import shop.data.Record;
import shop.data.Video;
import shop.data.Inventory;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class TEST1{

  private Inventory _inventory = Data.newInventory();

  public TEST1() {
        // No need to call super(), as JUnit 5 does not require a String parameter for the constructor
      }

  @Test
  private void check(Video v, int numOwned, int numOut, int numRentals) {
    Record r = _inventory.get(v);
    assertEquals(numOwned, r.numOwned());
    assertEquals(numOut, r.numOut());
    assertEquals(numRentals, r.numRentals());
  }

  @Test
  public void test1() {
    Command clearCmd = Data.newClearCmd(_inventory);
    clearCmd.run();
    
    Video v1 = Data.newVideo("Title1", 2000, "Director1");
    assertEquals(0, _inventory.size());
    assertTrue(Data.newAddCmd(_inventory, v1, 5).run());
    assertEquals(1, _inventory.size());
    assertTrue(Data.newAddCmd(_inventory, v1, 5).run());
    assertEquals(1, _inventory.size());
    check(v1,10,0,0);
   
  }

  @Test
    public void testAddAndDeleteVideos() {
        Command clearCmd = Data.newClearCmd(_inventory);
        clearCmd.run();

        Video v1 = Data.newVideo("Title1", 2000, "Director1");
        Video v2 = Data.newVideo("Title2", 2005, "Director2");

        assertTrue(Data.newAddCmd(_inventory, v1, 5).run());
        assertTrue(Data.newAddCmd(_inventory, v2, 3).run());

        assertEquals(2, _inventory.size());

        check(v1, 5, 0, 0);
        check(v2, 3, 0, 0);

    }
}
