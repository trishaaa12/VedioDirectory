package shop;

import shop.command.*;
import shop.data.Data;
import shop.data.Video;
import shop.data.Inventory;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TEST2 {

  public TEST2() {
    // No need to call super(), as JUnit 5 does not require a String parameter for the constructor
  }

  @Test
  public void test1() { 
    Inventory inventory = Data.newInventory();
    Video v1 = Data.newVideo("K", 2003, "S");
    RerunnableCommand UNDO = Data.newUndoCmd(inventory);
    RerunnableCommand REDO = Data.newRedoCmd(inventory);

    assertTrue(Data.newAddCmd(inventory, v1, 2).run());
    assertEquals("K (2003) : S [2,0,0]", inventory.get(v1).toString());

    assertTrue(Data.newOutCmd(inventory, v1).run());
    assertEquals("K (2003) : S [2,1,0]", inventory.get(v1).toString());

    assertTrue(UNDO.run());
    assertEquals("K (2003) : S [2,0,0]", inventory.get(v1).toString());

    assertTrue(REDO.run());
    assertEquals("K (2003) : S [2,1,0]", inventory.get(v1).toString());

    assertTrue(Data.newOutCmd(inventory, v1).run());
    assertEquals("K (2003) : S [2,2,0]", inventory.get(v1).toString());

    assertTrue(UNDO.run());
    assertEquals("K (2003) : S [2,1,0]", inventory.get(v1).toString());

    assertTrue(UNDO.run());
    assertEquals("K (2003) : S [2,0,0]", inventory.get(v1).toString());
  }

  @Test
  public void test2() {
    final Inventory inventory = Data.newInventory();
    final Video v1 = Data.newVideo("K", 2003, "S");
    final RerunnableCommand UNDO = Data.newUndoCmd(inventory);
    final RerunnableCommand REDO = Data.newRedoCmd(inventory);
    assertTrue  ( Data.newAddCmd(inventory, v1,2).run());
    assertEquals( "K (2003) : S [2,0,0]", inventory.get(v1).toString() );
    assertTrue  ( Data.newOutCmd(inventory, v1).run());
    assertEquals( "K (2003) : S [2,1,0]", inventory.get(v1).toString() );
    assertTrue  ( UNDO.run() );
    assertEquals( "K (2003) : S [2,0,0]", inventory.get(v1).toString() );
    assertTrue  ( REDO.run() );
    assertEquals( "K (2003) : S [2,1,0]", inventory.get(v1).toString() );
    assertTrue  ( Data.newOutCmd(inventory, v1).run());
    assertEquals( "K (2003) : S [2,2,0]", inventory.get(v1).toString() );
    assertTrue  ( UNDO.run() );
    assertEquals( "K (2003) : S [2,1,0]", inventory.get(v1).toString() );
    assertTrue  ( UNDO.run() );
    assertEquals( "K (2003) : S [2,0,0]", inventory.get(v1).toString() );
  }
}
